import React, { useState, useEffect } from "react";
import { db, auth } from "../../Firebase/Firebase.init";
import { collection, addDoc, getDoc, doc } from "firebase/firestore";
import { onAuthStateChanged } from "firebase/auth";
import { useNavigate } from "react-router-dom";

const CreateCourse = () => {
  const [course, setCourse] = useState({
    title: "",
    shortDescription: "",
    longDescription: "",
    thumbnail: "",
    category: "",
    price: "",
    startDate: "",
    endDate: "",
    lectureLength: "",
    qrCode: "",
    perksbenefits: "",
  });
  const [isAdmin, setIsAdmin] = useState(null);
  const [error, setError] = useState("");
  const navigate = useNavigate();

  useEffect(() => {
    const checkAdminStatus = async (user) => {
      if (!user) {
        navigate("/");
        return;
      }
      try {
        const userRef = doc(db, "users", user.uid);
        const userSnap = await getDoc(userRef);
        if (userSnap.exists() && userSnap.data().isAdmin === true) {
          setIsAdmin(true);
        } else {
          navigate("/");
        }
      } catch (error) {
        console.error("Error checking admin status:", error);
        navigate("/");
      }
    };

    const unsubscribe = onAuthStateChanged(auth, (user) => {
      checkAdminStatus(user);
    });

    return () => unsubscribe();
  }, [navigate]);

  const convertGoogleDriveLink = (url) => {
    const match = url.match(/\/d\/(.*?)\//);
    return match ? `https://drive.google.com/uc?export=view&id=${match[1]}` : url;
  };

  const handleChange = (e) => {
    let { name, value } = e.target;

    // Convert Google Drive URLs for QR Code and Thumbnail
    if ((name === "qrCode" || name === "thumbnail") && value.includes("drive.google.com")) {
      value = convertGoogleDriveLink(value);
    }

    setCourse((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");

    if (Object.values(course).some((field) => field.trim() === "")) {
      setError("All fields are required!");
      return;
    }

    const courseData = {
      ...course,
      thumbnail: course.thumbnail.trim(),
      qrCode: course.qrCode.trim(),
      price: parseFloat(course.price),
      createdAt: new Date(),
    };

    try {
      await addDoc(collection(db, "courses"), courseData);
      alert("Course added successfully!");
      setCourse({
        title: "",
        shortDescription: "",
        longDescription: "",
        thumbnail: "",
        category: "",
        price: "",
        startDate: "",
        endDate: "",
        lectureLength: "",
        qrCode: "",
        perksbenefits: "",
      });
    } catch (error) {
      console.error("Error adding course:", error);
      setError("Failed to add course. Please try again.");
    }
  };

  if (isAdmin === null) return <p>Loading...</p>;

  return (
    <div className="max-w-lg mx-auto mt-10">
      <h2 className="text-2xl font-bold mb-4">Create New Course</h2>
      {error && <p className="text-red-500">{error}</p>}
      <form onSubmit={handleSubmit} className="space-y-4">
        {[
          { label: "Course Title", name: "title", type: "text" },
          { label: "Short Description", name: "shortDescription", type: "text" },
          { label: "Long Description", name: "longDescription", type: "textarea" },
          { label: "Perks & Benefits", name: "perksbenefits", type: "textarea" },
          { label: "Thumbnail Image URL", name: "thumbnail", type: "text" },
          { label: "Category", name: "category", type: "text" },
          { label: "Price", name: "price", type: "number" },
          { label: "Start Date", name: "startDate", type: "date" },
          { label: "End Date", name: "endDate", type: "date" },
          { label: "Lecture Length (e.g., 1 week, 2 weeks)", name: "lectureLength", type: "text" },
          { label: "QR Image URL", name: "qrCode", type: "text" },
        ].map(({ label, name, type }) => (
          <div key={name}>
            <label>{label}</label>
            {type === "textarea" ? (
              <textarea
                name={name}
                value={course[name]}
                onChange={handleChange}
                className="w-full p-2 border border-gray-300 rounded"
                required
              />
            ) : (
              <input
                type={type}
                name={name}
                value={course[name]}
                onChange={handleChange}
                className="w-full p-2 border border-gray-300 rounded"
                required
              />
            )}
          </div>
        ))}

        <button type="submit" className="bg-indigo-500 text-white px-4 py-2 rounded">
          Create Course
        </button>
      </form>
    </div>
  );
};

export default CreateCourse;
